# YT Downloader : installation pas à pas

Tu n'as rien à installer sur ton ordinateur : GitHub construit l'application pour toi, gratuitement.
Il faut compter 15 minutes la première fois. Les étapes 1 à 4 se font sur l'ordinateur.

## 1. Créer un compte GitHub
- Va sur https://github.com et clique sur **Sign up**.
- Crée un compte gratuit (e-mail, mot de passe, nom d'utilisateur) et confirme ton e-mail.

## 2. Créer un « dépôt » (un dossier en ligne)
- Une fois connecté, clique sur le **+** en haut à droite, puis **New repository**.
- Nom : `yt-downloader`. Choisis **Public**. Ne coche rien d'autre.
- Clique sur **Create repository**.

## 3. Envoyer les fichiers
- Sur la page qui s'affiche, clique sur le lien **uploading an existing file**.
- Sur ton ordinateur, décompresse le ZIP, ouvre le dossier `YtDownloader`, sélectionne TOUT son contenu (Ctrl + A) et fais-le glisser dans la page GitHub.
  - Fais glisser le contenu du dossier, pas le dossier lui-même.
  - Le dossier `.github` doit être envoyé aussi : c'est lui qui lance la construction.
- Attends que tous les fichiers soient listés, puis clique sur le bouton vert **Commit changes**.

## 4. Attendre la construction (5 à 10 minutes)
- Clique sur l'onglet **Actions**. S'il y a un bouton « I understand my workflows, go ahead and enable them », clique dessus.
- Tu vois une ligne « Construire l'application » avec un rond jaune qui tourne. Quand il devient **vert** avec une coche, c'est fini.
- Si rien ne démarre : clique sur « Construire l'application » dans la colonne de gauche, puis **Run workflow**.

## 5. Récupérer l'application sur ton téléphone
- Sur ton téléphone, ouvre `github.com/TON-NOM/yt-downloader` dans le navigateur (remplace TON-NOM par ton nom d'utilisateur).
- À droite (ou en bas de la page), touche **Releases**, puis la dernière version « YT Downloader ».
- Touche **YT-Downloader.apk** pour le télécharger.
- Ouvre le fichier téléchargé. Android demande l'autorisation d'installer depuis le navigateur : accepte. Si Play Protect avertit, touche « Installer quand même ».

## 6. Utiliser l'application
1. **Réglages > Choisir le dossier (carte SD)** : choisis ta carte SD, ouvre ou crée un dossier (ex. « Musique »), touche « Utiliser ce dossier » puis « Autoriser ». Sur Android 11 et plus, la racine de la carte SD est refusée : prends un dossier à l'intérieur.
2. Toujours dans Réglages, choisis le format par défaut : **MP3** ou **MP4** (et la qualité pour la vidéo).
3. Onglet **Recherche** : tape un titre, valide avec la loupe. Touche le **+** à côté de chaque titre voulu.
4. Onglet **File d'attente** : vérifie ta sélection, puis **Tout télécharger**. Les fichiers arrivent dans ton dossier de la carte SD, même écran éteint.
- Pour une playlist ou une vidéo précise, colle son lien dans la barre de recherche : un bouton propose de l'ajouter à la file d'attente. Tu peux aussi partager un lien depuis l'application YouTube vers YT Downloader.

## En cas de problème
| Problème | Solution |
|---|---|
| Rond **rouge** dans l'onglet Actions | Touche la ligne rouge, ouvre l'étape en échec, copie le message d'erreur et envoie-le-moi : je corrige et te renvoie les fichiers. |
| Une mise à jour de l'app refuse de s'installer | Désinstalle d'abord l'ancienne version (la signature change à chaque construction), puis installe la nouvelle. |
| Un téléchargement échoue | Réglages > **Mettre à jour yt-dlp** (connexion Internet nécessaire), puis réessaie. |
| « Dossier inaccessible » | Carte SD retirée ou autorisation perdue : rechoisis le dossier dans Réglages. |
| Téléchargement coupé écran éteint | Réglages Android > Applications > YT Downloader > Batterie > « Sans restriction ». |

## Bon à savoir
- YouTube interdit le téléchargement dans ses conditions d'utilisation : réserve l'app à du contenu libre de droits ou que tu as le droit de copier.
- L'app ne peut pas aller sur le Play Store : elle s'installe uniquement par ce fichier APK.
- Pour modifier l'app plus tard, envoie-moi simplement ta demande : je te renvoie un nouveau ZIP, et tu refais les étapes 3 à 5.
