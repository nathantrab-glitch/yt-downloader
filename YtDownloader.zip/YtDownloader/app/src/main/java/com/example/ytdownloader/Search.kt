package com.example.ytdownloader

import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLRequest
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.CoroutineStart
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.launch
import java.util.UUID

data class SearchResult(val id: String, val title: String) {
    val url: String get() = "https://www.youtube.com/watch?v=$id"
}

/** Recherche YouTube via yt-dlp (titres seulement, sans images). */
object SearchModel {
    private const val PAGE = 20

    val results = MutableStateFlow<List<SearchResult>>(emptyList())
    val loading = MutableStateFlow(false)
    val error = MutableStateFlow<String?>(null)
    val query = MutableStateFlow("")

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var job: Job? = null
    private var currentProcess: String? = null
    private var count = PAGE

    fun search(text: String) {
        val q = text.trim()
        if (q.isEmpty()) return
        query.value = q
        count = PAGE
        results.value = emptyList()
        run(q, count)
    }

    fun more() {
        val q = query.value
        if (q.isEmpty() || loading.value) return
        count += PAGE
        run(q, count)
    }

    @Synchronized
    private fun run(q: String, n: Int) {
        job?.cancel()
        currentProcess?.let {
            try {
                YoutubeDL.getInstance().destroyProcessById(it)
            } catch (ignored: Throwable) {
            }
        }
        loading.value = true
        error.value = null

        val pid = "search-" + UUID.randomUUID()
        currentProcess = pid
        val newJob = scope.launch(start = CoroutineStart.LAZY) {
            val me = coroutineContext[Job]
            try {
                if (!Engine.awaitReady()) {
                    error.value = "Le moteur n'est pas prêt : ${Engine.message.value}"
                    return@launch
                }
                val list = fetch(q, n, pid)
                ensureActive()
                results.value = list
                if (list.isEmpty()) error.value = "Aucun résultat pour « $q »."
            } catch (e: CancellationException) {
                throw e
            } catch (t: Throwable) {
                if (job === me) error.value = friendly(t)
            } finally {
                if (job === me) loading.value = false
            }
        }
        job = newJob
        newJob.start()
    }

    private fun fetch(q: String, n: Int, pid: String): List<SearchResult> {
        val request = YoutubeDLRequest("ytsearch$n:$q")
        request.addOption("--flat-playlist")
        request.addOption("--no-warnings")
        request.addOption("--print", "%(id)s\t%(title)s")
        val response = YoutubeDL.getInstance().execute(request, pid)

        val seen = HashSet<String>()
        val list = ArrayList<SearchResult>()
        for (line in response.out.lines()) {
            val parts = line.trim().split('\t', limit = 2)
            if (parts.size < 2) continue
            val id = parts[0].trim()
            val title = parts[1].trim()
            if (id.length != 11 || title.isEmpty() || title == "NA") continue
            if (seen.add(id)) list.add(SearchResult(id, title))
        }
        return list
    }

    private fun friendly(t: Throwable): String {
        val raw = t.message?.trim().orEmpty()
        val line = raw.lines().map { it.trim() }.lastOrNull { it.isNotEmpty() }
        return "La recherche a échoué" + (if (line != null) " : ${line.removePrefix("ERROR:").trim().take(200)}" else ".")
    }
}
