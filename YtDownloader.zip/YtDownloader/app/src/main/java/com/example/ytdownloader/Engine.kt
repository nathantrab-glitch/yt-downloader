package com.example.ytdownloader

import android.app.Application
import com.yausername.ffmpeg.FFmpeg
import com.yausername.youtubedl_android.YoutubeDL
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.concurrent.thread

enum class EngineState { LOADING, READY, FAILED }

/**
 * Initialise yt-dlp + FFmpeg une seule fois, en arrière-plan.
 * Le [lock] garantit qu'un seul téléchargement (ou une mise à jour) tourne à la fois.
 */
object Engine {
    val state = MutableStateFlow(EngineState.LOADING)
    val message = MutableStateFlow("Initialisation du moteur de téléchargement…")
    val lock = Mutex()

    private val started = AtomicBoolean(false)

    fun start(app: Application) {
        if (!started.compareAndSet(false, true)) return
        state.value = EngineState.LOADING
        message.value = "Initialisation du moteur de téléchargement…"
        thread(name = "engine-init", isDaemon = true) {
            try {
                YoutubeDL.getInstance().init(app)
                FFmpeg.getInstance().init(app)
            } catch (t: Throwable) {
                message.value = "Échec de l'initialisation : ${t.message ?: t.javaClass.simpleName}"
                state.value = EngineState.FAILED
                started.set(false)
                return@thread
            }
            // YouTube change souvent : on met yt-dlp à jour à chaque lancement (si Internet disponible).
            message.value = "Mise à jour de yt-dlp…"
            tryUpdate(app)
            message.value = "Prêt"
            state.value = EngineState.READY
        }
    }

    /** Attend la fin de l'initialisation. Renvoie true si le moteur est prêt. */
    suspend fun awaitReady(): Boolean {
        val result = withTimeoutOrNull(180_000L) {
            state.first { it != EngineState.LOADING }
        }
        return result == EngineState.READY
    }

    /** Mise à jour manuelle de yt-dlp. Renvoie un message à afficher. */
    suspend fun updateNow(app: Application): String =
        lock.withLock {
            withContext(Dispatchers.IO) { tryUpdate(app) }
        }

    private fun tryUpdate(app: Application): String =
        try {
            when (YoutubeDL.getInstance().updateYoutubeDL(app, YoutubeDL.UpdateChannel.STABLE)) {
                YoutubeDL.UpdateStatus.DONE -> "yt-dlp a été mis à jour."
                else -> "yt-dlp est à jour."
            }
        } catch (t: Throwable) {
            "Mise à jour impossible : ${t.message ?: t.javaClass.simpleName}"
        }
}
