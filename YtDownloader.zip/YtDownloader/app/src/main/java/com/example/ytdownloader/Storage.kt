package com.example.ytdownloader

import android.content.Context
import android.net.Uri
import android.provider.DocumentsContract
import androidx.documentfile.provider.DocumentFile
import kotlinx.coroutines.flow.MutableStateFlow

private fun prefs(c: Context) =
    c.applicationContext.getSharedPreferences("settings", Context.MODE_PRIVATE)

/** Mémorise le dossier de destination choisi par l'utilisateur (via le sélecteur Android). */
object Prefs {
    private const val KEY_DEST = "dest_uri"

    fun getDest(c: Context): Uri? =
        prefs(c).getString(KEY_DEST, null)?.let { Uri.parse(it) }

    fun setDest(c: Context, uri: Uri?) {
        val editor = prefs(c).edit()
        if (uri == null) editor.remove(KEY_DEST) else editor.putString(KEY_DEST, uri.toString())
        editor.apply()
    }
}

/** Réglages de l'app (format, qualité, playlists), observables par l'écran. */
object Settings {
    private const val KEY_FORMAT = "format"
    private const val KEY_HEIGHT = "max_height"
    private const val KEY_PLAYLIST = "whole_playlist"

    val format = MutableStateFlow(Format.MP3)
    val maxHeight = MutableStateFlow(0)
    val wholePlaylist = MutableStateFlow(false)

    fun load(c: Context) {
        val p = prefs(c)
        format.value = try {
            Format.valueOf(p.getString(KEY_FORMAT, Format.MP3.name) ?: Format.MP3.name)
        } catch (ignored: IllegalArgumentException) {
            Format.MP3
        }
        maxHeight.value = p.getInt(KEY_HEIGHT, 0)
        wholePlaylist.value = p.getBoolean(KEY_PLAYLIST, false)
    }

    fun setFormat(c: Context, value: Format) {
        format.value = value
        prefs(c).edit().putString(KEY_FORMAT, value.name).apply()
    }

    fun setMaxHeight(c: Context, value: Int) {
        maxHeight.value = value
        prefs(c).edit().putInt(KEY_HEIGHT, value).apply()
    }

    fun setWholePlaylist(c: Context, value: Boolean) {
        wholePlaylist.value = value
        prefs(c).edit().putBoolean(KEY_PLAYLIST, value).apply()
    }
}

data class DestInfo(
    /** Texte lisible du dossier, ou null si aucun dossier n'a été choisi. */
    val label: String?,
    /** true si le dossier existe et qu'on a le droit d'y écrire maintenant. */
    val usable: Boolean,
)

object Storage {

    /** Renvoie le dossier de destination s'il est utilisable maintenant, sinon null. */
    fun destDir(ctx: Context): DocumentFile? {
        val uri = Prefs.getDest(ctx) ?: return null
        val hasPermission = ctx.contentResolver.persistedUriPermissions.any {
            it.uri == uri && it.isWritePermission
        }
        if (!hasPermission) return null
        val dir = DocumentFile.fromTreeUri(ctx, uri) ?: return null
        return try {
            if (dir.exists() && dir.canWrite()) dir else null
        } catch (ignored: Throwable) {
            null
        }
    }

    fun describe(ctx: Context): DestInfo {
        val uri = Prefs.getDest(ctx) ?: return DestInfo(null, false)
        return DestInfo(prettyUri(uri), destDir(ctx) != null)
    }

    private fun prettyUri(uri: Uri): String =
        try {
            val docId = DocumentsContract.getTreeDocumentId(uri) // ex. "A1B2-C3D4:Musique/YT"
            val volume = docId.substringBefore(':')
            val path = docId.substringAfter(':', "")
            val where = if (volume == "primary") "Stockage interne" else "Carte SD ($volume)"
            if (path.isEmpty()) where else "$where / $path"
        } catch (ignored: Throwable) {
            uri.toString()
        }
}
