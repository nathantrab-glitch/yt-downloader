package com.example.ytdownloader

import android.Manifest
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.storage.StorageManager
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.consumeWindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext

class MainActivity : ComponentActivity() {

    /** Incrémenté pour forcer le rafraîchissement de l'état du dossier de destination. */
    private var refreshTick by mutableIntStateOf(0)
    private var incomingText by mutableStateOf<String?>(null)

    private val pickFolder =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            val uri = result.data?.data
            if (result.resultCode == RESULT_OK && uri != null) onFolderPicked(uri)
        }

    private val askNotifications =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        if (savedInstanceState == null) handleIntent(intent)

        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            askNotifications.launch(Manifest.permission.POST_NOTIFICATIONS)
        }

        setContent {
            AppTheme {
                MainScreen(
                    refreshTick = refreshTick,
                    incomingText = incomingText,
                    onIncomingConsumed = { incomingText = null },
                    onPickFolder = { launchFolderPicker() },
                )
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIntent(intent)
    }

    override fun onResume() {
        super.onResume()
        refreshTick++
    }

    private fun handleIntent(i: Intent?) {
        if (i?.action == Intent.ACTION_SEND && i.type == "text/plain") {
            incomingText = i.getStringExtra(Intent.EXTRA_TEXT)
        }
    }

    private fun launchFolderPicker() {
        var intent: Intent? = null
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            try {
                val sm = getSystemService(Context.STORAGE_SERVICE) as StorageManager
                val sd = sm.storageVolumes.firstOrNull {
                    it.isRemovable && it.state == Environment.MEDIA_MOUNTED
                }
                intent = sd?.createOpenDocumentTreeIntent()
            } catch (ignored: Throwable) {
                intent = null
            }
        }
        val finalIntent = (intent ?: Intent(Intent.ACTION_OPEN_DOCUMENT_TREE)).addFlags(
            Intent.FLAG_GRANT_READ_URI_PERMISSION or
                Intent.FLAG_GRANT_WRITE_URI_PERMISSION or
                Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION or
                Intent.FLAG_GRANT_PREFIX_URI_PERMISSION
        )
        try {
            pickFolder.launch(finalIntent)
        } catch (ignored: ActivityNotFoundException) {
            Toast.makeText(this, "Aucun sélecteur de dossier disponible sur ce téléphone.", Toast.LENGTH_LONG).show()
        }
    }

    private fun onFolderPicked(uri: Uri) {
        val flags = Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
        try {
            contentResolver.takePersistableUriPermission(uri, flags)
        } catch (ignored: SecurityException) {
            Toast.makeText(
                this,
                "Ce dossier n'est pas utilisable. Choisis un dossier à l'intérieur de la carte SD (pas la racine).",
                Toast.LENGTH_LONG,
            ).show()
            return
        }
        val old = Prefs.getDest(this)
        if (old != null && old != uri) {
            try {
                contentResolver.releasePersistableUriPermission(old, flags)
            } catch (ignored: Exception) {
            }
        }
        Prefs.setDest(this, uri)
        refreshTick++
    }
}

private const val TAB_SEARCH = 0
private const val TAB_QUEUE = 1
private const val TAB_SETTINGS = 2

@Composable
private fun MainScreen(
    refreshTick: Int,
    incomingText: String?,
    onIncomingConsumed: () -> Unit,
    onPickFolder: () -> Unit,
) {
    val ctx = LocalContext.current
    val cart by Cart.items.collectAsState()
    val dest = remember(refreshTick) { Storage.describe(ctx) }

    var tab by rememberSaveable { mutableStateOf(TAB_SEARCH) }
    var searchText by rememberSaveable { mutableStateOf("") }
    val searchListState = rememberLazyListState()

    // Lien partagé depuis l'app YouTube : on le met dans la barre de recherche.
    LaunchedEffect(incomingText) {
        if (!incomingText.isNullOrBlank()) {
            searchText = incomingText
            tab = TAB_SEARCH
            onIncomingConsumed()
        }
    }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        bottomBar = {
            NavigationBar(containerColor = MaterialTheme.colorScheme.surface) {
                NavigationBarItem(
                    selected = tab == TAB_SEARCH,
                    onClick = { tab = TAB_SEARCH },
                    icon = { Icon(Icons.Default.Search, contentDescription = null) },
                    label = { Text("Recherche") },
                )
                NavigationBarItem(
                    selected = tab == TAB_QUEUE,
                    onClick = { tab = TAB_QUEUE },
                    icon = {
                        BadgedBox(
                            badge = {
                                if (cart.isNotEmpty()) Badge { Text(cart.size.toString()) }
                            },
                        ) {
                            Icon(Icons.Default.ShoppingCart, contentDescription = null)
                        }
                    },
                    label = { Text("File d'attente") },
                )
                NavigationBarItem(
                    selected = tab == TAB_SETTINGS,
                    onClick = { tab = TAB_SETTINGS },
                    icon = { Icon(Icons.Default.Settings, contentDescription = null) },
                    label = { Text("Réglages") },
                )
            }
        },
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .consumeWindowInsets(padding)
                .imePadding(),
        ) {
            EngineBanner()
            Box(modifier = Modifier.weight(1f)) {
                when (tab) {
                    TAB_SEARCH -> SearchScreen(
                        text = searchText,
                        onText = { searchText = it },
                        listState = searchListState,
                    )
                    TAB_QUEUE -> QueueScreen(
                        dest = dest,
                        onGoSettings = { tab = TAB_SETTINGS },
                    )
                    else -> SettingsScreen(
                        dest = dest,
                        onPickFolder = onPickFolder,
                    )
                }
            }
        }
    }
}
