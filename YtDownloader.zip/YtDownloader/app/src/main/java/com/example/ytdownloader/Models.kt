package com.example.ytdownloader

import com.yausername.youtubedl_android.YoutubeDL
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.update
import java.util.concurrent.ConcurrentHashMap

enum class Format { MP3, MP4 }

enum class Status { QUEUED, DOWNLOADING, COPYING, DONE, ERROR, CANCELED }

data class DownloadItem(
    val id: String,
    val url: String,
    val format: Format,
    val playlist: Boolean,
    /** Hauteur maximale de la vidéo (0 = meilleure qualité). */
    val maxHeight: Int,
    val title: String,
    val status: Status = Status.QUEUED,
    /** 0..1 ; valeur négative = progression indéterminée. */
    val progress: Float = 0f,
    val detail: String = "En attente…",
) {
    val isActive: Boolean
        get() = status == Status.QUEUED || status == Status.DOWNLOADING || status == Status.COPYING
}

/** Un titre mis de côté dans la file d'attente, avant de lancer les téléchargements. */
data class CartItem(val url: String, val title: String)

object Cart {
    private val _items = MutableStateFlow<List<CartItem>>(emptyList())
    val items: StateFlow<List<CartItem>> = _items

    fun add(item: CartItem) {
        _items.update { list -> if (list.any { it.url == item.url }) list else list + item }
    }

    fun remove(url: String) {
        _items.update { list -> list.filter { it.url != url } }
    }

    fun toggle(item: CartItem) {
        _items.update { list ->
            if (list.any { it.url == item.url }) list.filter { it.url != item.url } else list + item
        }
    }

    fun clear() {
        _items.value = emptyList()
    }
}

/** Liste des téléchargements, partagée entre le service et l'écran. */
object Downloads {
    private val _items = MutableStateFlow<List<DownloadItem>>(emptyList())
    val items: StateFlow<List<DownloadItem>> = _items

    private val jobs = ConcurrentHashMap<String, Job>()
    private val canceled: MutableSet<String> = ConcurrentHashMap.newKeySet<String>()

    fun add(item: DownloadItem) {
        _items.update { list -> listOf(item) + list }
    }

    /** Modifie un élément seulement s'il est encore actif (une annulation ne doit pas être écrasée). */
    fun updateIfActive(id: String, change: (DownloadItem) -> DownloadItem) {
        _items.update { list ->
            list.map { if (it.id == id && it.isActive) change(it) else it }
        }
    }

    fun setStatus(id: String, status: Status, detail: String) {
        _items.update { list ->
            list.map { if (it.id == id) it.copy(status = status, detail = detail) else it }
        }
    }

    fun clearFinished() {
        _items.update { list -> list.filter { it.isActive } }
    }

    fun registerJob(id: String, job: Job) {
        jobs[id] = job
    }

    fun unregisterJob(id: String) {
        jobs.remove(id)
    }

    fun isCanceled(id: String): Boolean = canceled.contains(id)

    fun cancel(id: String) {
        canceled.add(id)
        updateIfActive(id) { it.copy(status = Status.CANCELED, detail = "Annulé") }
        jobs[id]?.cancel()
        try {
            YoutubeDL.getInstance().destroyProcessById(id)
        } catch (ignored: Throwable) {
            // Rien à arrêter : tant mieux.
        }
    }

    fun cancelAll() {
        _items.value.filter { it.isActive }.forEach { cancel(it.id) }
    }
}
