package com.example.ytdownloader

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

private val LightColors = lightColorScheme(
    primary = Color(0xFFD6402B),
    onPrimary = Color.White,
    primaryContainer = Color(0xFFFFDAD3),
    onPrimaryContainer = Color(0xFF410A02),
    secondaryContainer = Color(0xFFFFE3DD),
    onSecondaryContainer = Color(0xFF3B0D06),
    background = Color(0xFFFAF6F4),
    onBackground = Color(0xFF1F1A19),
    surface = Color.White,
    onSurface = Color(0xFF1F1A19),
    surfaceVariant = Color(0xFFF1E7E4),
    onSurfaceVariant = Color(0xFF59504E),
    outline = Color(0xFF8C807D),
    outlineVariant = Color(0xFFE6DAD6),
    error = Color(0xFFB3261E),
)

private val DarkColors = darkColorScheme(
    primary = Color(0xFFFF8A75),
    onPrimary = Color(0xFF3A0E06),
    primaryContainer = Color(0xFF5C1F13),
    onPrimaryContainer = Color(0xFFFFDAD3),
    secondaryContainer = Color(0xFF442721),
    onSecondaryContainer = Color(0xFFFFDAD3),
    background = Color(0xFF131112),
    onBackground = Color(0xFFEDE0DD),
    surface = Color(0xFF1E1A1B),
    onSurface = Color(0xFFEDE0DD),
    surfaceVariant = Color(0xFF2B2425),
    onSurfaceVariant = Color(0xFFC9BAB6),
    outline = Color(0xFF8F8380),
    outlineVariant = Color(0xFF3B3233),
    error = Color(0xFFFFB4AB),
)

private val AppShapes = Shapes(
    small = RoundedCornerShape(12.dp),
    medium = RoundedCornerShape(18.dp),
    large = RoundedCornerShape(26.dp),
)

@Composable
fun AppTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = if (isSystemInDarkTheme()) DarkColors else LightColors,
        shapes = AppShapes,
        content = content,
    )
}
