package com.example.ytdownloader

import android.app.Application

class App : Application() {
    override fun onCreate() {
        super.onCreate()
        Settings.load(this)
        Engine.start(this)
    }
}
