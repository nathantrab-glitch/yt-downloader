package com.example.ytdownloader

import android.content.ClipboardManager
import android.content.Context
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.collectAsState
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp

/** Carte arrondie, sans ombre, avec un fin contour : le « look » de toute l'app. */
@Composable
fun AppCard(
    modifier: Modifier = Modifier,
    content: @Composable ColumnScope.() -> Unit,
) {
    Card(
        modifier = modifier.fillMaxWidth(),
        shape = MaterialTheme.shapes.medium,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
        content = content,
    )
}

@Composable
fun ScreenTitle(title: String, subtitle: String? = null) {
    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
        Text(
            title,
            style = MaterialTheme.typography.headlineMedium,
            fontWeight = FontWeight.Bold,
        )
        if (subtitle != null) {
            Text(
                subtitle,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }
}

/** Bandeau affiché tant que le moteur de téléchargement n'est pas prêt. */
@Composable
fun EngineBanner() {
    val state by Engine.state.collectAsState()
    val message by Engine.message.collectAsState()
    if (state == EngineState.READY) return

    val failed = state == EngineState.FAILED
    val app = LocalContext.current.applicationContext as android.app.Application
    androidx.compose.material3.Surface(
        color = if (failed) MaterialTheme.colorScheme.errorContainer else MaterialTheme.colorScheme.primaryContainer,
        modifier = Modifier.fillMaxWidth(),
    ) {
        Column(
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp),
        ) {
            Text(
                message,
                style = MaterialTheme.typography.bodyMedium,
                color = if (failed) MaterialTheme.colorScheme.onErrorContainer else MaterialTheme.colorScheme.onPrimaryContainer,
            )
            if (failed) {
                Button(onClick = { Engine.start(app) }) { Text("Réessayer") }
            } else {
                LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
            }
        }
    }
}

/** Choix MP3 / MP4 (+ qualité pour MP4), relié aux réglages. */
@Composable
fun FormatPicker() {
    val ctx = LocalContext.current
    val format by Settings.format.collectAsState()
    val maxHeight by Settings.maxHeight.collectAsState()

    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(
                selected = format == Format.MP3,
                onClick = { Settings.setFormat(ctx, Format.MP3) },
                label = { Text("MP3 · audio") },
            )
            FilterChip(
                selected = format == Format.MP4,
                onClick = { Settings.setFormat(ctx, Format.MP4) },
                label = { Text("MP4 · vidéo") },
            )
        }
        if (format == Format.MP4) {
            Text(
                "Qualité maximale de la vidéo",
                style = MaterialTheme.typography.labelLarge,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Row(
                modifier = Modifier.horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                for ((h, label) in QUALITIES) {
                    FilterChip(
                        selected = maxHeight == h,
                        onClick = { Settings.setMaxHeight(ctx, h) },
                        label = { Text(label) },
                    )
                }
            }
        }
    }
}

val QUALITIES = listOf(0 to "Max", 1080 to "1080p", 720 to "720p", 480 to "480p", 360 to "360p")

@Composable
fun DownloadCard(item: DownloadItem) {
    AppCard {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp),
        ) {
            Text(
                text = (if (item.format == Format.MP3) "MP3 · " else "MP4 · ") + item.title,
                style = MaterialTheme.typography.titleSmall,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
            )
            val detailColor = when (item.status) {
                Status.ERROR -> MaterialTheme.colorScheme.error
                Status.DONE -> MaterialTheme.colorScheme.primary
                else -> MaterialTheme.colorScheme.onSurfaceVariant
            }
            Text(
                text = item.detail,
                style = MaterialTheme.typography.bodySmall,
                color = detailColor,
                maxLines = 5,
                overflow = TextOverflow.Ellipsis,
            )
            if (item.status == Status.DOWNLOADING || item.status == Status.COPYING) {
                if (item.progress < 0f) {
                    LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
                } else {
                    LinearProgressIndicator(
                        progress = { item.progress },
                        modifier = Modifier.fillMaxWidth(),
                    )
                }
            }
            if (item.isActive) {
                TextButton(onClick = { Downloads.cancel(item.id) }) { Text("Annuler") }
            }
        }
    }
}

/** Récupère tous les liens http(s) d'un texte (on peut en coller plusieurs). */
fun extractUrls(text: String): List<String> =
    Regex("""https?://\S+""")
        .findAll(text)
        .map { it.value.trimEnd(',', ';', ')', '.', '"', '\'') }
        .filter { it.length > 8 }
        .distinct()
        .toList()

fun readClipboard(ctx: Context): String? {
    val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager ?: return null
    val clip = cm.primaryClip ?: return null
    if (clip.itemCount == 0) return null
    return clip.getItemAt(0).coerceToText(ctx)?.toString()
}
