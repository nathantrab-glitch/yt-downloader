package com.example.ytdownloader

import android.app.Application
import android.widget.Toast
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.launch

@Composable
fun SettingsScreen(dest: DestInfo, onPickFolder: () -> Unit) {
    val ctx = LocalContext.current
    val app = ctx.applicationContext as Application
    val scope = rememberCoroutineScope()
    val whole by Settings.wholePlaylist.collectAsState()
    val engineState by Engine.state.collectAsState()
    var updating by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        ScreenTitle("Réglages", "Où et comment enregistrer tes fichiers.")

        AppCard {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                Text("Destination", style = MaterialTheme.typography.titleMedium)
                when {
                    dest.label == null -> Text(
                        "Aucun dossier choisi.",
                        color = MaterialTheme.colorScheme.error,
                    )
                    !dest.usable -> Text(
                        "${dest.label}\nDossier inaccessible : carte SD retirée ou autorisation perdue. Rechoisis le dossier.",
                        color = MaterialTheme.colorScheme.error,
                    )
                    else -> Text(
                        dest.label.orEmpty(),
                        color = MaterialTheme.colorScheme.primary,
                        style = MaterialTheme.typography.bodyLarge,
                    )
                }
                Button(onClick = onPickFolder, modifier = Modifier.fillMaxWidth()) {
                    Text("Choisir le dossier (carte SD)")
                }
                Text(
                    "Dans la fenêtre qui s'ouvre : choisis ta carte SD, ouvre ou crée un dossier, " +
                        "puis touche « Utiliser ce dossier ». Sur Android 11 et plus, la racine de la carte SD " +
                        "est refusée par le système : prends un dossier à l'intérieur.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }

        AppCard {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                Text("Format par défaut", style = MaterialTheme.typography.titleMedium)
                FormatPicker()
            }
        }

        AppCard {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                Text("Playlists", style = MaterialTheme.typography.titleMedium)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                    Text(
                        "Si le lien d'une vidéo fait partie d'une playlist, télécharger toute la playlist",
                        modifier = Modifier.weight(1f),
                        style = MaterialTheme.typography.bodyMedium,
                    )
                    Switch(checked = whole, onCheckedChange = { Settings.setWholePlaylist(ctx, it) })
                }
                Text(
                    "Un lien de playlist (youtube.com/playlist?list=…) est toujours téléchargé en entier.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }

        AppCard {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                Text("Moteur de téléchargement", style = MaterialTheme.typography.titleMedium)
                Text(
                    "YouTube change souvent. L'app met yt-dlp à jour à chaque lancement ; " +
                        "si un téléchargement échoue, essaie la mise à jour manuelle.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                OutlinedButton(
                    onClick = {
                        updating = true
                        scope.launch {
                            val msg = Engine.updateNow(app)
                            updating = false
                            Toast.makeText(ctx, msg, Toast.LENGTH_LONG).show()
                        }
                    },
                    enabled = engineState == EngineState.READY && !updating,
                    modifier = Modifier.fillMaxWidth(),
                ) {
                    Text(if (updating) "Mise à jour…" else "Mettre à jour yt-dlp")
                }
            }
        }
    }
}
