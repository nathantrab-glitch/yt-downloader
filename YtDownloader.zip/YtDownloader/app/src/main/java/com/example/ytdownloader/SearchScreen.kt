package com.example.ytdownloader

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.FilledTonalIconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp

@Composable
fun SearchScreen(
    text: String,
    onText: (String) -> Unit,
    listState: LazyListState,
) {
    val results by SearchModel.results.collectAsState()
    val loading by SearchModel.loading.collectAsState()
    val error by SearchModel.error.collectAsState()
    val cart by Cart.items.collectAsState()
    val focus = LocalFocusManager.current

    val urls = remember(text) { extractUrls(text) }
    val inCart = remember(cart) { cart.map { it.url }.toSet() }

    fun doSearch() {
        focus.clearFocus()
        if (urls.isEmpty() && text.isNotBlank()) SearchModel.search(text)
    }

    Column(modifier = Modifier.fillMaxSize()) {
        Column(
            modifier = Modifier.padding(start = 16.dp, end = 16.dp, top = 16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            ScreenTitle("Rechercher", "Trouve un titre, ou colle un lien YouTube.")

            OutlinedTextField(
                value = text,
                onValueChange = onText,
                modifier = Modifier.fillMaxWidth(),
                placeholder = { Text("Titre, artiste, lien…") },
                singleLine = true,
                shape = RoundedCornerShape(28.dp),
                trailingIcon = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        if (text.isNotEmpty()) {
                            IconButton(onClick = { onText("") }) {
                                Icon(Icons.Default.Close, contentDescription = "Effacer")
                            }
                        }
                        IconButton(onClick = { doSearch() }) {
                            Icon(Icons.Default.Search, contentDescription = "Rechercher")
                        }
                    }
                },
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                keyboardActions = KeyboardActions(onSearch = { doSearch() }),
            )

            if (urls.isNotEmpty()) {
                AppCard {
                    Column(
                        modifier = Modifier.padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        Text(
                            if (urls.size > 1) "${urls.size} liens détectés" else "Lien détecté",
                            style = MaterialTheme.typography.titleSmall,
                        )
                        Button(
                            onClick = {
                                urls.forEach { Cart.add(CartItem(it, it)) }
                                focus.clearFocus()
                                onText("")
                            },
                        ) {
                            Text("Ajouter à la file d'attente")
                        }
                    }
                }
            }
        }

        LazyColumn(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f),
            state = listState,
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 12.dp, bottom = 16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            if (results.isEmpty()) {
                item {
                    when {
                        loading -> LoadingRow("Recherche en cours…")
                        error != null -> Text(
                            error.orEmpty(),
                            color = MaterialTheme.colorScheme.error,
                            style = MaterialTheme.typography.bodyMedium,
                        )
                        else -> Text(
                            "Tape un titre puis valide avec la loupe.",
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            style = MaterialTheme.typography.bodyMedium,
                        )
                    }
                }
            }

            items(results, key = { it.id }) { r ->
                val added = r.url in inCart
                ResultRow(
                    title = r.title,
                    added = added,
                    onToggle = { Cart.toggle(CartItem(r.url, r.title)) },
                )
            }

            if (results.isNotEmpty()) {
                item {
                    if (loading) {
                        LoadingRow("Chargement…")
                    } else {
                        OutlinedButton(
                            onClick = { SearchModel.more() },
                            modifier = Modifier.fillMaxWidth(),
                        ) {
                            Text("Plus de résultats")
                        }
                    }
                }
                if (error != null && !loading) {
                    item {
                        Text(
                            error.orEmpty(),
                            color = MaterialTheme.colorScheme.error,
                            style = MaterialTheme.typography.bodySmall,
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun LoadingRow(label: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        CircularProgressIndicator(modifier = Modifier.size(20.dp), strokeWidth = 2.dp)
        Text(label, style = MaterialTheme.typography.bodyMedium)
    }
}

@Composable
private fun ResultRow(title: String, added: Boolean, onToggle: () -> Unit) {
    AppCard {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(start = 16.dp, end = 10.dp, top = 8.dp, bottom = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Text(
                text = title,
                modifier = Modifier.weight(1f),
                style = MaterialTheme.typography.bodyLarge,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
            )
            if (added) {
                FilledIconButton(onClick = onToggle) {
                    Icon(Icons.Default.Check, contentDescription = "Dans la file d'attente (toucher pour retirer)")
                }
            } else {
                FilledTonalIconButton(onClick = onToggle) {
                    Icon(Icons.Default.Add, contentDescription = "Ajouter à la file d'attente")
                }
            }
        }
    }
}
