package com.example.ytdownloader

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.os.SystemClock
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import androidx.documentfile.provider.DocumentFile
import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLRequest
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.CoroutineStart
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.withLock
import java.io.File
import java.io.IOException
import java.util.UUID
import java.util.concurrent.atomic.AtomicInteger

/**
 * Service au premier plan : télécharge avec yt-dlp dans un dossier temporaire de l'app,
 * puis copie les fichiers terminés dans le dossier choisi (carte SD) via le Storage Access Framework.
 */
class DownloadService : Service() {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val active = AtomicInteger(0)
    private val lastStartId = AtomicInteger(0)
    private val doneCount = AtomicInteger(0)
    private val failCount = AtomicInteger(0)
    private var wakeLock: PowerManager.WakeLock? = null

    private val nm: NotificationManager by lazy {
        getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        createChannels()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        lastStartId.set(startId)
        ensureForeground()
        when (intent?.action) {
            ACTION_CANCEL_ALL -> Downloads.cancelAll()
            ACTION_ADD -> if (intent != null) enqueue(intent)
        }
        if (active.get() == 0) finishService()
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        if (active.get() > 0) Downloads.cancelAll()
        scope.cancel()
        releaseWakeLock()
        super.onDestroy()
    }

    // ------------------------------------------------------------------ file d'attente

    private fun enqueue(intent: Intent) {
        val urls = intent.getStringArrayListExtra(EXTRA_URLS).orEmpty()
        val titles = intent.getStringArrayListExtra(EXTRA_TITLES).orEmpty()
        val format = try {
            Format.valueOf(intent.getStringExtra(EXTRA_FORMAT) ?: "")
        } catch (ignored: IllegalArgumentException) {
            Format.MP3
        }
        val wholePlaylist = intent.getBooleanExtra(EXTRA_PLAYLIST, false)
        val maxHeight = intent.getIntExtra(EXTRA_HEIGHT, 0)

        for ((i, url) in urls.withIndex()) {
            val item = DownloadItem(
                id = UUID.randomUUID().toString(),
                url = url,
                format = format,
                playlist = wantsPlaylist(url, wholePlaylist),
                maxHeight = maxHeight,
                title = titles.getOrNull(i)?.takeIf { it.isNotBlank() } ?: url,
            )
            Downloads.add(item)
            active.incrementAndGet()
            acquireWakeLock()

            val job = scope.launch(start = CoroutineStart.LAZY) {
                try {
                    runJob(item)
                } catch (t: Throwable) {
                    handleFailure(item.id, t)
                } finally {
                    Downloads.unregisterJob(item.id)
                    onJobFinished()
                }
            }
            Downloads.registerJob(item.id, job)
            job.start()
        }
    }

    /** Un lien « /playlist » est toujours une playlist ; une vidéo d'une playlist seulement si demandé. */
    private fun wantsPlaylist(url: String, wholePlaylist: Boolean): Boolean {
        if (url.contains("/playlist?")) return true
        return wholePlaylist && url.contains("list=") && !url.contains("list=RD")
    }

    private fun onJobFinished() {
        if (active.decrementAndGet() <= 0) {
            postSummary()
            Handler(Looper.getMainLooper()).post { finishService() }
        }
    }

    private fun finishService() {
        if (active.get() > 0) return
        releaseWakeLock()
        try {
            stopForeground(STOP_FOREGROUND_REMOVE)
        } catch (ignored: Throwable) {
        }
        stopSelf(lastStartId.get())
    }

    // ------------------------------------------------------------------ un téléchargement

    private suspend fun runJob(item: DownloadItem) {
        val id = item.id
        Engine.lock.withLock {
            if (Downloads.isCanceled(id)) throw CancellationException("annulé")

            Downloads.updateIfActive(id) {
                it.copy(status = Status.DOWNLOADING, progress = -1f, detail = "Préparation…")
            }
            notifyOngoing(item.url, -1f)

            if (!ensureEngine()) {
                fail(id, "Le moteur de téléchargement n'a pas pu démarrer : ${Engine.message.value}")
                return
            }
            val destDir = Storage.destDir(this)
            if (destDir == null) {
                fail(id, "Dossier de destination inaccessible. Rechoisis-le dans l'app (carte SD bien insérée ?).")
                return
            }

            val base = getExternalFilesDir(null) ?: filesDir
            val tmp = File(base, "tmp/$id")
            try {
                tmp.deleteRecursively()
                tmp.mkdirs()

                val failure = download(item, tmp)
                if (Downloads.isCanceled(id)) throw CancellationException("annulé")

                val files = tmp.walkTopDown()
                    .filter { isFinalFile(it, item.format) }
                    .sortedBy { it.name.lowercase() }
                    .toList()

                if (files.isEmpty()) {
                    fail(id, errorText(failure) ?: "Aucun fichier n'a été téléchargé.")
                    return
                }
                copyAll(item, files, destDir, failure)
            } finally {
                tmp.deleteRecursively()
            }
        }
    }

    private suspend fun ensureEngine(): Boolean {
        if (Engine.state.value == EngineState.FAILED) Engine.start(application)
        return Engine.awaitReady()
    }

    /** Lance yt-dlp. Renvoie l'erreur éventuelle (les fichiers déjà terminés restent utilisables). */
    private fun download(item: DownloadItem, tmp: File): Throwable? {
        val id = item.id
        val request = buildRequest(item, tmp)

        val reIndex = Regex("""Downloading (?:item|video) (\d+) of (\d+)""")
        val rePercent = Regex("""\[download]\s+(\d+(?:\.\d+)?)%""")
        val reDest = Regex("""\[(?:download|ExtractAudio)] Destination: (.+)""")

        var index = 1
        var total = 1
        var lastNotify = 0L

        Downloads.updateIfActive(id) {
            it.copy(status = Status.DOWNLOADING, progress = -1f, detail = "Récupération des informations…")
        }

        return try {
            YoutubeDL.getInstance().execute(request, id) { _, _, line ->
                reIndex.find(line)?.let { m ->
                    index = m.groupValues[1].toIntOrNull() ?: index
                    total = (m.groupValues[2].toIntOrNull() ?: total).coerceAtLeast(1)
                }
                val percent = rePercent.find(line)?.groupValues?.get(1)?.toFloatOrNull()
                val newTitle = reDest.find(line)?.groupValues?.get(1)?.let { cleanTitle(it) }
                val phase = when {
                    line.startsWith("[ExtractAudio]") -> "Conversion en MP3…"
                    line.startsWith("[Merger]") -> "Assemblage audio + vidéo…"
                    line.startsWith("[Metadata]") -> "Ajout des informations…"
                    else -> null
                }

                if (percent != null || newTitle != null || phase != null) {
                    val overall = if (percent != null) {
                        (((index - 1) + percent / 100f) / total).coerceIn(0f, 0.99f)
                    } else {
                        null
                    }
                    var shownTitle = item.url
                    Downloads.updateIfActive(id) { cur ->
                        val t = newTitle ?: cur.title
                        shownTitle = t
                        val text = when {
                            phase != null -> phase
                            percent != null && total > 1 ->
                                "Élément $index/$total · ${percent.toInt()} %"
                            percent != null -> "${percent.toInt()} %"
                            else -> cur.detail
                        }
                        cur.copy(
                            status = Status.DOWNLOADING,
                            title = t,
                            progress = overall ?: cur.progress,
                            detail = text,
                        )
                    }
                    val now = SystemClock.elapsedRealtime()
                    if (now - lastNotify > 1000) {
                        lastNotify = now
                        notifyOngoing(shownTitle, overall ?: -1f)
                    }
                }
            }
            null
        } catch (e: YoutubeDL.CanceledException) {
            throw e
        } catch (e: InterruptedException) {
            throw e
        } catch (e: Exception) {
            e
        }
    }

    private fun buildRequest(item: DownloadItem, tmp: File): YoutubeDLRequest {
        val r = YoutubeDLRequest(item.url)
        r.addOption("-o", File(tmp, "%(title)s.%(ext)s").absolutePath)
        r.addOption("--newline")
        r.addOption("--no-mtime")
        r.addOption("--windows-filenames")
        r.addOption("--trim-filenames", "120")
        r.addOption("--ignore-errors")
        r.addOption("--retries", "10")
        r.addOption("--fragment-retries", "10")
        r.addOption("--socket-timeout", "30")
        r.addOption(if (item.playlist) "--yes-playlist" else "--no-playlist")

        when (item.format) {
            Format.MP3 -> {
                r.addOption("-f", "bestaudio/best")
                r.addOption("-x")
                r.addOption("--audio-format", "mp3")
                r.addOption("--audio-quality", "0")
                r.addOption("--embed-metadata")
            }
            Format.MP4 -> {
                r.addOption("-f", mp4Selector(item.maxHeight))
                r.addOption("--merge-output-format", "mp4")
            }
        }
        return r
    }

    /** Préfère H.264 + AAC (lisible partout), avec plusieurs solutions de repli. */
    private fun mp4Selector(maxHeight: Int): String {
        val h = if (maxHeight > 0) "[height<=?$maxHeight]" else ""
        return "bv*[vcodec^=avc1]$h+ba[ext=m4a]/" +
            "bv*[ext=mp4]$h+ba[ext=m4a]/" +
            "b[ext=mp4]$h/" +
            "bv*$h+ba/" +
            "b$h"
    }

    private fun isFinalFile(f: File, format: Format): Boolean {
        if (!f.isFile || f.length() == 0L) return false
        // Fichiers intermédiaires de yt-dlp (ex. « titre.f137.mp4 ») : on les ignore.
        if (Regex("""\.f\d+$""").containsMatchIn(f.nameWithoutExtension)) return false
        val ext = f.extension.lowercase()
        return when (format) {
            Format.MP3 -> ext == "mp3"
            Format.MP4 -> ext == "mp4" || ext == "mkv" || ext == "webm"
        }
    }

    private fun cleanTitle(path: String): String =
        File(path.trim()).nameWithoutExtension.replace(Regex("""\.f\d+$"""), "")

    // ------------------------------------------------------------------ copie vers la carte SD

    private suspend fun copyAll(
        item: DownloadItem,
        files: List<File>,
        destDir: DocumentFile,
        failure: Throwable?,
    ) {
        val id = item.id
        val totalBytes = files.sumOf { it.length() }.coerceAtLeast(1L)
        var doneBytes = 0L
        var lastUpdate = 0L

        Downloads.updateIfActive(id) {
            it.copy(status = Status.COPYING, progress = 0f, detail = "Copie vers le dossier choisi…")
        }
        notifyOngoing("Copie vers le dossier choisi…", 0f)

        val names = ArrayList<String>()
        for (f in files) {
            currentCoroutineContext().ensureActive()
            val finalName = copyToDir(f, destDir, id) { n ->
                doneBytes += n
                val now = SystemClock.elapsedRealtime()
                if (now - lastUpdate > 300) {
                    lastUpdate = now
                    val p = (doneBytes.toFloat() / totalBytes).coerceIn(0f, 1f)
                    Downloads.updateIfActive(id) { it.copy(progress = p) }
                }
            }
            names.add(finalName)
        }

        val detail = when {
            failure != null ->
                "${files.size} fichier(s) copié(s), mais certains éléments ont échoué : " +
                    (errorText(failure) ?: "erreur inconnue")
            files.size == 1 -> "Terminé : ${names[0]}"
            else -> "Terminé : ${files.size} fichiers"
        }
        val title = if (files.size == 1) names[0].substringBeforeLast('.') else "${files.size} fichiers"

        doneCount.incrementAndGet()
        Downloads.updateIfActive(id) {
            it.copy(status = Status.DONE, title = title, progress = 1f, detail = detail)
        }
    }

    private fun copyToDir(src: File, dir: DocumentFile, id: String, onBytes: (Long) -> Unit): String {
        val name = uniqueName(dir, src.name)
        val dst = dir.createFile(mimeOf(src.extension), name)
            ?: throw IOException("Impossible de créer « $name » dans le dossier choisi.")
        try {
            contentResolver.openOutputStream(dst.uri, "w").use { out ->
                if (out == null) throw IOException("Impossible d'écrire dans le dossier choisi.")
                src.inputStream().use { input ->
                    val buffer = ByteArray(256 * 1024)
                    while (true) {
                        val n = input.read(buffer)
                        if (n < 0) break
                        out.write(buffer, 0, n)
                        onBytes(n.toLong())
                        if (Downloads.isCanceled(id)) throw CancellationException("annulé")
                    }
                    out.flush()
                }
            }
        } catch (t: Throwable) {
            try {
                dst.delete()
            } catch (ignored: Throwable) {
            }
            throw t
        }
        return dst.name ?: name
    }

    private fun uniqueName(dir: DocumentFile, name: String): String {
        if (dir.findFile(name) == null) return name
        val base = name.substringBeforeLast('.', name)
        val ext = name.substringAfterLast('.', "")
        var i = 1
        while (true) {
            val candidate = if (ext.isEmpty()) "$base ($i)" else "$base ($i).$ext"
            if (dir.findFile(candidate) == null) return candidate
            i++
        }
    }

    private fun mimeOf(ext: String): String =
        when (ext.lowercase()) {
            "mp3" -> "audio/mpeg"
            "m4a" -> "audio/mp4"
            "mp4" -> "video/mp4"
            "webm" -> "video/webm"
            "mkv" -> "video/x-matroska"
            else -> "application/octet-stream"
        }

    // ------------------------------------------------------------------ erreurs

    private fun fail(id: String, message: String) {
        failCount.incrementAndGet()
        Downloads.updateIfActive(id) { it.copy(status = Status.ERROR, detail = message) }
    }

    private fun handleFailure(id: String, t: Throwable) {
        val canceled = t is CancellationException ||
            t is YoutubeDL.CanceledException ||
            Downloads.isCanceled(id)
        if (canceled) {
            Downloads.setStatus(id, Status.CANCELED, "Annulé")
        } else {
            fail(id, errorText(t) ?: "Erreur inconnue.")
        }
    }

    private fun errorText(t: Throwable?): String? {
        if (t == null) return null
        val raw = t.message?.trim().orEmpty()
        if (raw.isEmpty()) return t.javaClass.simpleName
        val lines = raw.lines().map { it.trim() }.filter { it.isNotEmpty() }
        val line = lines.lastOrNull { it.startsWith("ERROR") } ?: lines.last()
        return line.removePrefix("ERROR:").trim().take(300)
    }

    // ------------------------------------------------------------------ notifications

    private fun createChannels() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            nm.createNotificationChannel(
                NotificationChannel(CH_ONGOING, "Téléchargements en cours", NotificationManager.IMPORTANCE_LOW)
            )
            nm.createNotificationChannel(
                NotificationChannel(CH_DONE, "Téléchargements terminés", NotificationManager.IMPORTANCE_DEFAULT)
            )
        }
    }

    private fun openAppIntent(): PendingIntent =
        PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )

    private fun ongoingNotification(text: String, progress: Float): Notification {
        val cancelIntent = PendingIntent.getService(
            this,
            1,
            Intent(this, DownloadService::class.java).setAction(ACTION_CANCEL_ALL),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        val builder = NotificationCompat.Builder(this, CH_ONGOING)
            .setSmallIcon(android.R.drawable.stat_sys_download)
            .setContentTitle("YT Downloader")
            .setContentText(text)
            .setOnlyAlertOnce(true)
            .setOngoing(true)
            .setContentIntent(openAppIntent())
            .addAction(0, "Tout annuler", cancelIntent)
            .setForegroundServiceBehavior(NotificationCompat.FOREGROUND_SERVICE_IMMEDIATE)
        if (progress < 0f) {
            builder.setProgress(0, 0, true)
        } else {
            builder.setProgress(100, (progress * 100).toInt().coerceIn(0, 100), false)
        }
        return builder.build()
    }

    private fun ensureForeground() {
        try {
            val n = ongoingNotification("Téléchargement en cours…", -1f)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                startForeground(NOTIF_ONGOING, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
            } else {
                startForeground(NOTIF_ONGOING, n)
            }
        } catch (ignored: Throwable) {
            // Si le système refuse, le téléchargement continue tant que l'app reste ouverte.
        }
    }

    private fun notifyOngoing(text: String, progress: Float) {
        try {
            nm.notify(NOTIF_ONGOING, ongoingNotification(text, progress))
        } catch (ignored: Throwable) {
        }
    }

    private fun postSummary() {
        val ok = doneCount.getAndSet(0)
        val ko = failCount.getAndSet(0)
        if (ok + ko == 0) return
        val text = buildString {
            if (ok > 0) append("$ok terminé(s)")
            if (ko > 0) {
                if (isNotEmpty()) append(" · ")
                append("$ko en échec")
            }
        }
        try {
            val n = NotificationCompat.Builder(this, CH_DONE)
                .setSmallIcon(android.R.drawable.stat_sys_download_done)
                .setContentTitle("Téléchargements terminés")
                .setContentText(text)
                .setAutoCancel(true)
                .setContentIntent(openAppIntent())
                .build()
            nm.notify(NOTIF_DONE, n)
        } catch (ignored: Throwable) {
        }
    }

    // ------------------------------------------------------------------ verrou de veille

    private fun acquireWakeLock() {
        try {
            if (wakeLock == null) {
                val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
                wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "ytdownloader:download")
            }
            wakeLock?.let { if (!it.isHeld) it.acquire(6 * 60 * 60 * 1000L) }
        } catch (ignored: Throwable) {
        }
    }

    private fun releaseWakeLock() {
        try {
            wakeLock?.let { if (it.isHeld) it.release() }
        } catch (ignored: Throwable) {
        }
    }

    companion object {
        private const val ACTION_ADD = "com.example.ytdownloader.ADD"
        private const val ACTION_CANCEL_ALL = "com.example.ytdownloader.CANCEL_ALL"
        private const val EXTRA_URLS = "urls"
        private const val EXTRA_TITLES = "titles"
        private const val EXTRA_FORMAT = "format"
        private const val EXTRA_PLAYLIST = "playlist"
        private const val EXTRA_HEIGHT = "height"

        private const val CH_ONGOING = "downloads"
        private const val CH_DONE = "done"
        private const val NOTIF_ONGOING = 1001
        private const val NOTIF_DONE = 1002

        fun start(
            ctx: Context,
            urls: List<String>,
            titles: List<String>,
            format: Format,
            wholePlaylist: Boolean,
            maxHeight: Int,
        ) {
            val intent = Intent(ctx, DownloadService::class.java)
                .setAction(ACTION_ADD)
                .putStringArrayListExtra(EXTRA_URLS, ArrayList(urls))
                .putStringArrayListExtra(EXTRA_TITLES, ArrayList(titles))
                .putExtra(EXTRA_FORMAT, format.name)
                .putExtra(EXTRA_PLAYLIST, wholePlaylist)
                .putExtra(EXTRA_HEIGHT, maxHeight)
            ContextCompat.startForegroundService(ctx, intent)
        }
    }
}
