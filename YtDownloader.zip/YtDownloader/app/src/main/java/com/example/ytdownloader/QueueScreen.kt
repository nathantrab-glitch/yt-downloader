package com.example.ytdownloader

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp

@Composable
fun QueueScreen(dest: DestInfo, onGoSettings: () -> Unit) {
    val ctx = LocalContext.current
    val cart by Cart.items.collectAsState()
    val downloads by Downloads.items.collectAsState()
    val format by Settings.format.collectAsState()
    val maxHeight by Settings.maxHeight.collectAsState()
    val whole by Settings.wholePlaylist.collectAsState()

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        item {
            ScreenTitle("File d'attente", "Les titres choisis, prêts à être téléchargés.")
        }

        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
            ) {
                Text(
                    "Ma sélection (${cart.size})",
                    style = MaterialTheme.typography.titleMedium,
                )
                if (cart.isNotEmpty()) {
                    TextButton(onClick = { Cart.clear() }) { Text("Tout vider") }
                }
            }
        }

        if (cart.isEmpty()) {
            item {
                Text(
                    "Vide pour l'instant. Dans l'onglet Recherche, touche « + » à côté d'un titre pour l'ajouter ici.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }

        items(cart, key = { it.url }) { c ->
            AppCard {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(start = 16.dp, end = 6.dp, top = 6.dp, bottom = 6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    Text(
                        c.title,
                        modifier = Modifier.weight(1f),
                        style = MaterialTheme.typography.bodyLarge,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis,
                    )
                    IconButton(onClick = { Cart.remove(c.url) }) {
                        Icon(Icons.Default.Close, contentDescription = "Retirer")
                    }
                }
            }
        }

        if (cart.isNotEmpty()) {
            item {
                AppCard {
                    Column(
                        modifier = Modifier.padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp),
                    ) {
                        Text("Télécharger en", style = MaterialTheme.typography.titleSmall)
                        FormatPicker()

                        Button(
                            onClick = {
                                DownloadService.start(
                                    ctx = ctx,
                                    urls = cart.map { it.url },
                                    titles = cart.map { it.title },
                                    format = format,
                                    wholePlaylist = whole,
                                    maxHeight = if (format == Format.MP4) maxHeight else 0,
                                )
                                Cart.clear()
                            },
                            enabled = dest.usable,
                            modifier = Modifier.fillMaxWidth(),
                        ) {
                            Text(
                                (if (cart.size == 1) "Télécharger 1 titre" else "Tout télécharger (${cart.size})") +
                                    " en " + (if (format == Format.MP3) "MP3" else "MP4"),
                            )
                        }

                        if (!dest.usable) {
                            Text(
                                "Choisis d'abord le dossier de destination (carte SD) dans les réglages.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.error,
                            )
                            TextButton(onClick = onGoSettings) { Text("Ouvrir les réglages") }
                        } else if (dest.label != null) {
                            Text(
                                "Destination : ${dest.label}",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                    }
                }
            }
        }

        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
            ) {
                Text("Téléchargements", style = MaterialTheme.typography.titleMedium)
                if (downloads.any { !it.isActive }) {
                    TextButton(onClick = { Downloads.clearFinished() }) { Text("Effacer les terminés") }
                }
            }
        }

        if (downloads.isEmpty()) {
            item {
                Text(
                    "Aucun téléchargement pour l'instant.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }

        items(downloads, key = { it.id }) { d ->
            DownloadCard(d)
        }
    }
}
